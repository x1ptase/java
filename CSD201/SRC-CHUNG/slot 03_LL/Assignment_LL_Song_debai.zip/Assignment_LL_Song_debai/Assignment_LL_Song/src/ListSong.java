
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author PHAM KHAC VINH
 */
public class ListSong {

    SongNode head, tail;

    public void readFromFile(String fileName) {
        File file = new File(fileName);
        ArrayList<Song> listSongs = new ArrayList<>();
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                System.err.println("IO Exception phan file");
            }
        }
        Song product;
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        try {
            fileReader = new FileReader(file);
            bufferedReader = new BufferedReader(fileReader);
            String lineString = "";
            while (true) {
                //doc du lieu cua 1 dong
                lineString = bufferedReader.readLine();
                if (lineString == null) {
                    break;
                }
                String[] txt = lineString.split("[|]+");
                String name = txt[0].trim();
                String artist = txt[1].trim();
                int rated = Integer.parseInt(txt[2].trim());
                Song song = new Song(name, artist, rated);
                addLast(song, "y", 1);
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            try {
                fileReader.close();
                bufferedReader.close();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            System.err.println("File Not Found Exception in function " + "readFromFile");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.err.println("IO Exception cua ham buffereader trong readFromFile");
        }
    }

    public void writeFile(String fileName) {
        FileWriter fileWriter = null;
        BufferedWriter bufferedWriter = null;
        try {

            fileWriter = new FileWriter(fileName);
            bufferedWriter = new BufferedWriter(fileWriter);
            //lap tu gia tri dau tien den gia tri cuoi cung cua mang chuoi
            SongNode currentNode = head;
            while (currentNode != null) {
                bufferedWriter.write(currentNode.info.toString());
                bufferedWriter.newLine();
                currentNode = currentNode.next;

            }

        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bufferedWriter.close();
                fileWriter.close();
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    void addLast(Song x) {
        SongNode qNode = new SongNode(x);
        if (isEmpty()) {
            head = tail = qNode;
            return;
        }
        tail.next = qNode;
        tail = qNode;

    }

    void addLast(Song x, String name, int rated) {
        SongNode qNode = new SongNode(x);
        if (qNode.info.getName().equals(name) || qNode.info.getRated() <= rated) {
            return;
        } else {
            if (isEmpty()) {
                head = tail = qNode;
                return;
            }
            tail.next = qNode;
            tail = qNode;
        }
    }

    boolean isEmpty() {
        return (head == null);
    }

    void q1() {
        readFromFile("songs.txt");
    }

    void q2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void q3() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void q4() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void q5() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void q6() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void q7() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
