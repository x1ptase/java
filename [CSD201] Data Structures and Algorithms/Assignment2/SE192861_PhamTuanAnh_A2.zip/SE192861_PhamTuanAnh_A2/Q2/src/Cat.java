// =========== DO NOT EDIT THE GIVEN CONTENT OF THIS FILE ============
class Cat {
  String place;
  int weight,color;
  Cat() {
   }
  Cat(String xPlace, int xWeight, int xColor){
    place=xPlace;weight=xWeight; color=xColor;
   }
  public String toString(){
    return("(" + place +","+ weight + "," + color + ")");
   }
 }
