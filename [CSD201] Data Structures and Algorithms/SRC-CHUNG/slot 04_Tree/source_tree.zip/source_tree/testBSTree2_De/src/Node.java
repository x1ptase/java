public class Node {
  int info;
  Node left,right;
  Node(int x) {
    info=x;left=right=null;  
  }
}
